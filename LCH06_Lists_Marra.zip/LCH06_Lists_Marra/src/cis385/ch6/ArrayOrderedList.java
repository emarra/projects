package cis385.ch6;

import cis385.ch6.exceptions.NonComparableElementException;

/**
 * ArrayOrderedList represents an array implementation of an ordered list.
 * @author Dr. Lewis
 * @author Dr. Chase
 * @modified Eric Marra
 * @version 1.2, 10/14/2019
 */
public class ArrayOrderedList<T> extends ArrayList<T> //Cannot be an object of any type, must have an order
		implements OrderedListADT<T> {

	/**
	 * Creates an empty list using the default capacity.
	 */
	public ArrayOrderedList() {
		super();
	}

	/**
	 * Creates an empty list using the specified capacity.
	 * @param initialCapacity the integer initial size of the list
	 */
	public ArrayOrderedList(int initialCapacity) {
		super(initialCapacity);
	}

	/**
	 * Adds the specified Comparable element to this list, keeping the elements
	 * in sorted order. 
	 * @param element the element to be added to this list
	 * @throws NonComparableElementException, checks that the element type is comparable
	 */
	@SuppressWarnings("unchecked")
	public void add(T element) {

		if (size() == list.length)
			expandCapacity();
		
		Comparable<T> temp;
		try {
			temp = (Comparable<T>) element;
		} catch (ClassCastException e) {
			throw new NonComparableElementException("ArrayOrderedList");
		}	
			
		int scan = 0;
		while (scan < back && temp.compareTo(list[scan]) > 0)
			scan++;

		for (int scan2 = back; scan2 > scan; scan2--)
			list[scan2] = list[scan2 - 1];

		list[scan] = element;
		back++;
		modCount++;
	}
}
