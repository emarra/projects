package cis385.ch6;

import static org.junit.Assert.*;
import java.util.Iterator;
import org.junit.Test;
import cis385.ch6.exceptions.*;

public class ArrayOrderedListTest {

	@Test
	public void testIteratorReturnsElementsInOrder() {

		ArrayOrderedList<String> list = new ArrayOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("ape");
		list.add("bug");

		Iterator<String> iterator = list.iterator();

		assertEquals("ape", iterator.next());
		assertEquals("bug", iterator.next());
		assertEquals("cat", iterator.next());
		assertEquals("dog", iterator.next());

	}

	@Test
	public void testRemoveFirstRemovesAndReturnsFirstItem() {

		ArrayOrderedList<String> list = new ArrayOrderedList<String>();
		list.add("ape");
		list.add("bug");
		list.add("cat");
		list.add("dog");

		assertEquals("ape", list.removeFirst());
		assertEquals(3, list.size());
		assertFalse(list.contains("ape"));

	}

	@Test
	public void testRemoveLastRemovesAndReturnsLastItem() {

		ArrayOrderedList<String> list = new ArrayOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("ape");
		list.add("bug");

		assertEquals("dog", list.removeLast());
		assertEquals(3, list.size());
		assertFalse(list.contains("dog"));

	}

	@Test
	public void testRemoveRemovesAndReturnsSpecifiedItem() {

		ArrayOrderedList<String> list = new ArrayOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("ape");
		list.add("bug");

		assertEquals("bug", list.remove("bug"));
		assertEquals(3, list.size());
		assertFalse(list.contains("bug"));

	}

	@Test
	public void testToStringIncludesAllItemsInOrder() {

		ArrayOrderedList<String> list = new ArrayOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("ape");
		list.add("bug");

		String listString = list.toString();

		// find expected substrings in list.toString();
		int a, b, c, d;

		a = listString.indexOf("ape");
		b = listString.indexOf("bug");
		c = listString.indexOf("cat");
		d = listString.indexOf("dog");

		// toString() contains each of the elements
		assertTrue(a >= 0);
		assertTrue(b >= 0);
		assertTrue(c >= 0);
		assertTrue(d >= 0);

		// elements appear in order
		assertTrue(a < b);
		assertTrue(b < c);
		assertTrue(c < d);

	}

	@Test
	public void testAddNonComparableElementThrowsNonComparableElementException() {
		
		ArrayOrderedList<Dogs> pets = new ArrayOrderedList<Dogs>();
		
		Dogs d1 = new Dogs("Marty");

		try {
			pets.add(d1);
			fail("Should throw NonComparableElementException");
		} catch (NonComparableElementException e) {
			//do nothing
		}
	}

}
