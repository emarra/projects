package cis385.ch6;

import cis385.ch6.exceptions.*;

/**
 * ArrayUnorderedList represents an array implementation of an unordered list.
 * @author Dr. Lewis
 * @author Dr. Chase
 * @version 1.1, 10/08/2015
 */
public class ArrayUnorderedList<T> extends ArrayList<T>
		implements UnorderedListADT<T> {

	/**
	 * Creates an empty list using the default capacity.
	 */
	public ArrayUnorderedList() {
		super();
	}

	/**
	 * Creates an empty list using the specified capacity.
	 * @param initialCapacity the integer intial size of the list
	 */
	public ArrayUnorderedList(int initialCapacity) {
		super(initialCapacity);
	}

	/**
	 * Adds the specified element to the front of this list.
	 * @param element the element to be added to the front of the list
	 */
	public void addToFront(T element) {

		if (size() == list.length)
			expandCapacity();

		/** shift elements to make room */
		for (int scan = back; scan > 0; scan--)
			list[scan] = list[scan - 1];

		list[0] = element;
		back++;
		modCount++;
	}

	/**
	 * Adds the specified element to the rear of this list.
	 * @param element the element to be added to the list
	 */
	public void addToBack(T element) {

		if (size() == list.length)
			expandCapacity();

		list[back] = element;
		back++;
		modCount++;
	}

	/**
	 * Adds the specified element after the specified target element. Throws an
	 * ElementNotFoundException if the target is not found.
	 * @param element the element to be added after the target element
	 * @param target the target that the element is to be added after
	 */
	public void addAfter(T element, T target) {

		if (size() == list.length)
			expandCapacity();

		int scanFromLeft = 0;
		while (scanFromLeft < back && !target.equals(list[scanFromLeft]))
			scanFromLeft++;

		if (scanFromLeft == back)
			throw new ElementNotFoundException("list");

		scanFromLeft++;
		for (int scanFromRight = back; scanFromRight > scanFromLeft; scanFromRight--)
			list[scanFromRight] = list[scanFromRight - 1];

		list[scanFromLeft] = element;
		back++;
		modCount++;
	}
}
