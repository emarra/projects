/**
 * This is a class to create a simple dog object for testing purposes
 * @author Eric Marra
 */

package cis385.ch6;

public class Dogs {
	
	private String name;
	private String breed;
	
	public Dogs(String name) {
		super();
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getBreed() {
		return breed;
	}
	
	public void setBreed(String breed) {
		this.breed = breed;
	}
	
	
}
