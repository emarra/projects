/**
 * Creates a linked ordered list using LinkedList.java and provides 
 * an add method.
 * @author Eric Marra
 */
package cis385.ch6;

import cis385.ch6.exceptions.NonComparableElementException;

public class LinkedOrderedList<T> extends LinkedList<T>
			implements OrderedListADT<T> {
	
	/**
	 * Create a LinkedOrderedList using constructors in LinkList.java
	 */
	public LinkedOrderedList(){
		super();
	}

	/**
	 * Add an element to a list in the correct order in which that element belongs.
	 * Element types must be comparable to each other.
	 * @param T element, the element to add
	 * @throws NonComparableElementException, checks to make sure that the list type
	 * is able to be compared.
	 */
	@SuppressWarnings("unchecked")
	public void add(T element)
			throws NonComparableElementException{
		
		LinearNode<T> newNode = new LinearNode<T>(element);
		LinearNode<T> current = head;
		
		Comparable<T> temp;
		try {
			temp = (Comparable<T>) element;
		} catch (ClassCastException e) {
			throw new NonComparableElementException("LinkedOrderedList");
		}	 
		
		if(count == 0) {
			head = tail = newNode;
			
		} else {
			
			while (current.getNext() != null && temp.compareTo(current.getElement()) > 0) {
				current = current.getNext();
			}
			
			if (current.equals(head) && temp.compareTo(current.getElement()) <= 0) {
				current.setPrev(newNode);
				newNode.setNext(current);
				head = newNode;
				
			} else if (current.equals(tail) && temp.compareTo(current.getElement()) > 0) {
				current.setNext(newNode);
				newNode.setPrev(current);
				tail = newNode;
				
			} else {
				current.getPrev().setNext(newNode);
				newNode.setNext(current);
				newNode.setPrev(current.getPrev());
				current.setPrev(newNode);
			}
		}
		
		count++;
		modCount++;
	}
}
