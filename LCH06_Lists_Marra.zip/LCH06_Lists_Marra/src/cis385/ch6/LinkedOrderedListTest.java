/**
 * The JUnit tests for the LinkedOrderedList object.
 * @author Eric Marra
 */
package cis385.ch6;

import static org.junit.Assert.*;
import java.util.Iterator;
import org.junit.Test;
import cis385.ch6.exceptions.NonComparableElementException;

public class LinkedOrderedListTest {

	@Test
	public void addAnElementToAnEmptyList() {
		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		
		list.add("Chocolate");
		
		assertEquals(list.first(), "Chocolate");
	}
	
	@Test
	public void addAnElementToAListWithOneElement() {
		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		
		list.add("b");
		list.add("a");
		
		assertEquals(list.first(), "a");
		assertEquals(list.last(), "b");
	}
	
	@Test
	public void addAnElementToAListWithMultipleEntries() {
		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		
		list.add("b");
		list.add("z");
		list.add("a");
		list.add("g");
		
		assertEquals(list.first(), "a");
		assertEquals(list.getTail().getPrev().getPrev().getElement(), "b" );
		assertEquals(list.getTail().getPrev().getElement(), "g");
		assertEquals(list.last(), "z");
	}
	
	@Test
	public void sizeIncreasesAsElementsAdded() {
		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		assertEquals(list.size(), 0);
		
		list.add("b");
		list.add("a");
		list.add("d");
		list.add("c");
		
		assertEquals(list.size(), 4);
	}
	
	@Test (expected = NonComparableElementException.class)
	public void listOfNoncomparableElementsThrowsException() {
		LinkedOrderedList<Dogs> list = new LinkedOrderedList<Dogs>();
		
		Dogs d1 = new Dogs("Marty");
		list.add(d1);
	}
	
	
	@Test
	public void testIteratorReturnsElementsInOrder() {

		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("ape");
		list.add("bug");

		Iterator<String> iterator = list.iterator();

		assertEquals("ape", iterator.next());
		assertEquals("bug", iterator.next());
		assertEquals("cat", iterator.next());
		assertEquals("dog", iterator.next());
	}

	@Test
	public void testRemoveFirstRemovesAndReturnsFirstItem() {
		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		list.add("ape");
		list.add("bug");
		list.add("cat");
		list.add("dog");
		
		assertEquals("ape", list.removeFirst());
		assertEquals(3, list.size());
		assertFalse(list.contains("ape"));
	}
	
	@Test
	public void testRemoveLastRemovesAndReturnsLastItem() {

		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("ape");
		list.add("bug");

		assertEquals("dog", list.removeLast());
		assertEquals(3, list.size());
		assertFalse(list.contains("dog"));

	}

	@Test
	public void testRemoveRemovesAndReturnsSpecifiedItem() {

		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("ape");
		list.add("bug");

		assertEquals("bug", list.remove("bug"));
		assertEquals(3, list.size());
		assertFalse(list.contains("bug"));

	}
	@Test
	public void addingDublicateElementsGroupsThemTogether() {
		
		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		list.add("dog");
		list.add("cat");
		list.add("dog");
		list.add("bug");

		assertEquals(list.last(), list.getTail().getPrev().getElement());
	}
	
}
