/**
 * This class creates an unordered list that uses LinkedList.java
 * and adds addToFront(), addToBack, and addAfter().
 * @author Eric Marra
 */

package cis385.ch6;

import cis385.ch6.exceptions.ElementNotFoundException;
import cis385.ch6.exceptions.EmptyCollectionException;

public class LinkedUnorderedList<T> extends LinkedList<T>
			implements UnorderedListADT<T> {
	
	/**
	 * Will create an unordered list using linkedlist.java
	 */
	public LinkedUnorderedList() {
		super();
	}

	/**
	 * Will add and element to the front of the linked list
	 * @param T element the element to add
	 */
	public void addToFront(T element) {
		
		LinearNode<T> newNode = new LinearNode<T>(element);
		if(count == 0) {
			head = tail = newNode;
			newNode.setPrev(null);
			
		} else {
			newNode.setNext(head);
			head.setPrev(newNode);
			head = newNode;
		}

		count++;
		modCount++;
	}
	
	/**
	 * Will add an element to the back of the list
	 * @param T element the element that is added
	 */
	public void addToBack(T element) {

		LinearNode<T> newNode = new LinearNode<T>(element);
		if(count == 0) {
			head = tail = newNode;
			newNode.setPrev(null);
			
		} else {
			tail.setNext(newNode);
			newNode.setPrev(tail);
			tail = newNode;
		}
		
		count++;
		modCount++;
	}
	
	/**
	 * Will add an element after a target element on the list.
	 * @param T element, T targetElement, the element to be added and 
	 * where to add it
	 * @throws EmptyCollectionException, ElementNotFoundException
	 * checks if the list is not empty and the target element exists.
	 */
	public void addAfter(T element, T targetElement)
			throws EmptyCollectionException, ElementNotFoundException{
		
		if (isEmpty())
			throw new EmptyCollectionException("LinkedUnorderedList");

		boolean found = false;
		LinearNode<T> newNode = new LinearNode<T>(element);
		LinearNode<T> current = head;

		while (current != null && !found)
			if (targetElement.equals(current.getElement())) {
				found = true;
			} else {
				current = current.getNext();
			}

		if (!found)
			throw new ElementNotFoundException("LinkedUnorderedList");

		if (current.equals(tail) || size() == 1) {
			tail.setNext(newNode);
			newNode.setPrev(tail);
			tail = newNode;
			
		} else {
			current.getNext().setPrev(newNode);
			newNode.setPrev(current);
			newNode.setNext(current.getNext());
			current.setNext(newNode);
		}
		
		count++;
		modCount++;
	}
}
