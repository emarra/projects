package cis385.ch6;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import cis385.ch6.exceptions.ElementNotFoundException;
import cis385.ch6.exceptions.EmptyCollectionException;


public class LinkedUnorderedListTest {

	@Before
	public void setUp() throws Exception {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
	}

	@Test
	public void testAddToFrontOnEmptyList() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		// conditions before addToFront
		assertTrue(list.isEmpty());
		assertEquals(0, list.size());
		
		// addToFront operation
		list.addToFront("Turkic");
		
		// conditions after addToFront
		assertFalse(list.isEmpty());
		assertEquals(1, list.size());
		assertEquals("Turkic", list.first());
		assertEquals("Turkic", list.last());
	}

	@Test
	public void testAddToFrontOnSingleElementList() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToFront("Chocolate");
		list.addToFront("Vanilla");
		assertEquals(list.first(), "Vanilla");
	}

	@Test
	public void testAddToFrontOnMultipleElementList() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToFront("Chocolate");
		assertEquals(list.first(), "Chocolate");
		
		list.addToFront("Vanilla");
		assertEquals(list.first(), "Vanilla");
		
		list.addToFront("Strawberry");
		assertEquals(list.first(), "Strawberry");
	}

	@Test
	public void testAddToBackOnEmptyList() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToBack("Chocolate");
		assertEquals(list.last(), "Chocolate");
	}

	@Test
	public void testAddToBackOnSingleElementList() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToBack("Chocolate");
		list.addToBack("Vanilla");
		assertEquals(list.last(), "Vanilla");
	}

	@Test
	public void testAddToBackOnMultipleElementList() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToBack("Chocolate");
		assertEquals(list.last(), "Chocolate");
		
		list.addToBack("Vanilla");
		assertEquals(list.last(), "Vanilla");
		
		list.addToBack("Strawberry");
		assertEquals(list.last(), "Strawberry");
	}

	@Test ( expected = EmptyCollectionException.class )
	public void testAddAfterOnEmptyList() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		assertTrue(list.isEmpty());
		list.addAfter("Vanilla", "Chocolate");		
	}

	@Test
	public void testAddAfterOnSingleElementListTargetFound() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToFront("Chocolate");
		list.addAfter("Vanilla", "Chocolate");
		assertEquals(list.last(), "Vanilla");
		assertEquals(list.first(), "Chocolate");
	}

	@Test ( expected = ElementNotFoundException.class )
	public void testAddAfterOnSingleElementListTargetNotFound() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToFront("Chocolate");
		list.addAfter("Vanilla", "Peanutbutter");
	}

	@Test
	public void testAddAfterOnMulitpleElementListTargetAtFront() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToFront("Chocolate");
		list.addToFront("Vanilla");
		list.addAfter("Strawberry","Vanilla");
		assertEquals(list.getHead().getNext().getElement(), "Strawberry");
	}

	@Test
	public void testAddAfterOnMultipleElementListTargetAtBack() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToBack("Chocolate");
		list.addToBack("Vanilla");
		list.addToBack("Strawberry");
		list.addAfter("Peanutbutter","Strawberry");
		assertEquals(list.last(), "Peanutbutter");
		assertEquals(list.getTail().getPrev().getElement(), "Strawberry");
	}

	@Test
	public void testAddAfterOnMultipleElementListTargetInMiddle() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToFront("Chocolate");
		list.addToFront("Vanilla");
		list.addToFront("Strawberry");
		list.addAfter("Peanutbutter","Vanilla");
		assertEquals(list.getHead().getNext().getNext().getElement(), "Peanutbutter");
	}

	@Test ( expected = ElementNotFoundException.class )
	public void testAddAfterOnMultipleElementListTargetNotFound() {
		LinkedUnorderedList<String> list = new LinkedUnorderedList<String>();
		
		list.addToFront("Chocolate");
		list.addToFront("Vanilla");
		list.addToFront("Strawberry");
		list.addAfter("Peanutbutter","CookieDough");
	}

}
