package cis385.ch8;

import java.lang.Math;

/**
 * Implementation of recursive functions specified in
 * RecursiveFunctionsInterface
 * @author Gene Rohrbaugh
 * @version 1.1
 * @modified October 2019 by Eric Marra
 *
 */
public class RecursiveFunctions implements RecursiveFunctionsInterface {

	/**
	 * Returns the given string repeated the given number of times
	 * @param string the string to be repeated
	 * @param times the number of times
	 * @return string repeated number of times
	 * @throws IllegalArgumentException if times is less than 0
	 */
	public String repeat(String string, int times) {

		if (times < 0)
			throw new IllegalArgumentException("times must be non-negative");
		else if (times == 0)
			return "";
		else
			return string + repeat(string, times - 1);
	}

	/**
	 * Returns true if string contains character, false otherwise
	 * @param string the string to be checked
	 * @param character the character being searched for
	 * @return true if string contains character, false otherwise
	 */
	public Boolean contains(String string, char character) {

		if (string.length() == 0)
			return false;
		else if (string.charAt(0) == character)
			return true;
		else
			return contains(string.substring(1), character);
	}

	/**
	 * Calculates the value of fibonacci sequence at the nth position.
	 * @param the position in the fibonacci sequence to calculate
	 * @return the value calculated
	 * @throws IllegalArgumentException if n is negative
	 */
	@Override
	public int fibonacci(int n) throws IllegalArgumentException {
		
		if (n < 0) {
			throw new IllegalArgumentException();
		} else if (n == 0 || n == 1){
			return n;
		} else {
			return fibonacci(n - 1) + fibonacci(n - 2);
		}
	}

	/**
	 * Multiplies to given numbers together.
	 * @param int x, the first value to multiply
	 * @param int y, the second value to multiply
	 * @return the product of the two numbers
	 */
	@Override
	public int multiply(int x, int y) {
		
		if (y > 0) {
			return x + multiply(x, y - 1);
		} else if (y < 0) {
			return -x + multiply(x, y + 1);
		} else {
			return 0;
		}
	}

	/**
	 * Calculates the power using two ints where one is the base
	 * and the other is the exponent.
	 * @param int base, the base that will raised to a power.
	 * @param int exponent, the value that the base will be raised to.
	 * @return the result of the base and the exponenet
	 * @throws IllegalArgumentException if exponent is negative.
	 */
	@Override
	public int power(int base, int exponent) throws IllegalArgumentException {
		
		if (exponent < 0) {
			throw new IllegalArgumentException(); 
		} else if (exponent == 0) {
			return 1;
		} else if (exponent == 1) {
			return base;
		} else {
			return base * power(base, exponent - 1);
		}
	}

	/**
	 * Calculates the power using a double and an int where one is the base
	 * and the other is the exponent.
	 * @param double base, the base that will raised to a power.
	 * @param int exponent, the value that the base will be raised to.
	 * @return the result of the base and the exponenet
	 * @throws IllegalArgumentException if exponent is negative.
	 */
	@Override
	public double power(double base, int exponent) throws IllegalArgumentException {
		
		if (exponent < 0) {
			throw new IllegalArgumentException(); 
		} else if (exponent == 0) {
			return 1.0;
		} else if (exponent == 1) {
			return base;
		} else {
			return base * power(base, exponent - 1);
		}
	}

	/**
	 * Finds the greatest common denominator of the two given integers
	 * @param int x, the first number
	 * @param int y, the second number
	 * @return the greatest common denominator
	 * @throws illegalArgumentException if both numbers are 0
	 */
	@Override
	public int gcd(int x, int y) throws IllegalArgumentException{
		x = Math.abs(x);
		y = Math.abs(y);
	
		if ( x == 0 && y == 0) {
			throw new IllegalArgumentException();
		} else if (x == 0) {
			return y;
		} else if (x == y || y == 0){
			return x;
		} else if (x > y) {
			return gcd(x - y, y);
		} else {
			return gcd(x, y - x);
		}
	}
	
	/**
	 * Will determine if the entered string is a palindrome
	 * @param String phrase, the string that is being examined
	 * @returns a boolean depending on if it is a palindrome or not.
	 */
	@Override
	public boolean isPalindrome(String phrase) {
		phrase = phrase.toLowerCase();
		phrase = phrase.replaceAll("[^a-z]", "");
		
		if (phrase.length() <= 1) {
			return true;
		}else if (phrase.charAt(0) == phrase.charAt(phrase.length() - 1)){
			return isPalindrome(phrase.substring(1, phrase.length() - 1));
		} else {
			return false;
		}
	}
}
