package cis385.ch8;

/**
 * Interface specifying a set of functions to be implemented via recursion.
 * @author Gene Rohrbaugh
 * @version 1.1
 * @modified October 2019 by Eric Marra
 */
public interface RecursiveFunctionsInterface {

	/**
	 * Returns the given string repeated the given number of times
	 * @param string the string to be repeated
	 * @param times the number of times
	 * @return string repeated number of times
	 * @throws IllegalArgumentException if times is less than 0
	 */
	public String repeat(String string, int times)
			throws IllegalArgumentException;

	/**
	 * Returns true if string contains character, false otherwise
	 * @param string the string to be checked
	 * @param character the character being searched for
	 * @return true if string contains character, false otherwise
	 */
	public Boolean contains(String string, char character);

	/**
	 * Returns the nth number in the Fibonacci sequence, where
	 * 		f(0) -> 0 and f(1) -> 1
	 * @param n number of sequential element to be returned
	 * @return nth Fibonacci number
	 * @throws IllegalArgumentException if n < 0
	 */
	public int fibonacci(int n) throws IllegalArgumentException;

	/**
	 * Muliplies any two integers and returns result. Should work
	 * for all possible integers, including positive, negative, and 0
	 * @param x first operand
	 * @param y second operand
	 * @return result of x * y
	 */
	public int multiply(int x, int y);

	/**
	 * Returns the value of a base raised to an exponent. Note this version
	 * returns an integer, so negative exponents should throw an exception
	 * since they result in fractional values.
	 * @param base
	 * @param exponent
	 * @return base^exponent
	 * @throws IllegalArgumentException if exponent < 0
	 */
	public int power(int base, int exponent) throws IllegalArgumentException;

	/**
	 * Returns the value of a base raised to an exponent. Note this version
	 * returns an double, so negative exponents are allowed. All combinations
	 * of positive and negative bases and exponents should work correctly.
	 * @param base
	 * @param exponent
	 * @return
	 */
	public double power(double base, int exponent);

	/**
	 * Returns the Greatest Common Divisor of two integers, using
	 * Euclid's algorithm.
	 * @param x
	 * @param y
	 * @return the greatest common divisor of x and y
	 */
	public int gcd(int x, int y);

	/**
	 * Returns true if the given string is a palindrome, ignoring case
	 * and any non-alphabetic characters.
	 * @param phrase phrase to be tested
	 * @return true if phrase is a palindrome; false otherwise
	 */
	public boolean isPalindrome(String phrase);

}
