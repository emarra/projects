package cis385.ch8;

import static org.junit.Assert.*;
import org.junit.Test;

public class RecursiveFunctionsTest {

	@Test
	public void repeatZeroTimesReturnsEmptyString() {

		RecursiveFunctions functions = new RecursiveFunctions();

		assertEquals("", functions.repeat("Happy", 0));

	}

	@Test
	public void repeatReturnsStringRepeated() {

		RecursiveFunctions functions = new RecursiveFunctions();

		assertTrue("HappyHappyHappy".equals(functions.repeat("Happy", 3)));

	}
	
	@Test(expected = IllegalArgumentException.class)
	public void repeatThrowsIllegalArgumentExceptionForNegativeTimes() {

		RecursiveFunctions functions = new RecursiveFunctions();

		functions.repeat("Happy", -5);

	}

	@Test
	public void containsReturnsFalseForEmptyString() {
		
		RecursiveFunctions functions = new RecursiveFunctions();

		assertFalse(functions.contains("", 'a'));
		
	}

	@Test
	public void containsReturnsFalseCharNotFound() {
		
		RecursiveFunctions functions = new RecursiveFunctions();

		assertFalse(functions.contains("Tamil", 'e'));
		
	}

	@Test
	public void containsReturnsTrueForCharAtBeginning() {
		
		RecursiveFunctions functions = new RecursiveFunctions();

		assertTrue(functions.contains("Tamil", 'T'));
		
	}

	@Test
	public void containsReturnsTrueForCharInMiddle() {
		
		RecursiveFunctions functions = new RecursiveFunctions();

		assertTrue(functions.contains("Tamil", 'm'));
		
	}

	@Test
	public void containsReturnsTrueForCharAtEnd() {
		
		RecursiveFunctions functions = new RecursiveFunctions();

		assertTrue(functions.contains("Tamil", 'l'));
		
	}

	@Test
	public void testFibonacciThrowsExceptionForNegativeArgs() {
		RecursiveFunctions functions = new RecursiveFunctions();
				
		try {
			functions.fibonacci(-1);
			fail("fibonacci should throw exception illegal argument");
		} catch (IllegalArgumentException e) {
			//do nothing
		}
	}
	
	@Test
	public void testFibonacciZeroReturnsZero() {
		RecursiveFunctions functions = new RecursiveFunctions();
				
		assertEquals(0, functions.fibonacci(0));
	}
	
	@Test
	public void testFibonacciOneReturnsOne() {
		RecursiveFunctions functions = new RecursiveFunctions();
				
		assertEquals(1, functions.fibonacci(1));
	}
	
	@Test
	public void testFibonacciReturnsExpectedValue() {
		RecursiveFunctions functions = new RecursiveFunctions();
				
		assertEquals(1, functions.fibonacci(2));
		assertEquals(2, functions.fibonacci(3));
		assertEquals(3, functions.fibonacci(4));
		assertEquals(5, functions.fibonacci(5));
		assertEquals(8, functions.fibonacci(6));
		assertEquals(13, functions.fibonacci(7));
		assertEquals(21, functions.fibonacci(8));
	}
	
	@Test
	public void testMultiplyReturnsZeroWhenMultipliedByZero() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(0, functions.multiply(10, 0));
	}
	
	@Test
	public void testMultiplyReturnsExpectedValues() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(10, functions.multiply(10, 1));
		assertEquals(121, functions.multiply(11, 11));
		assertEquals(45, functions.multiply(3, 15));
	}
	
	@Test
	public void testMultiplyReturnsExpectedValuesWithSignedMultiplication() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(-10, functions.multiply(10, -1));
		assertEquals(-121, functions.multiply(-11, 11));
		assertEquals(45, functions.multiply(-3, -15));
	}

	@Test
	public void testPowerReturnsExceptionWhenExponentIsNegative() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		try {
			functions.power(5, -1);
			fail("Power should throw exception illegal argument");
		} catch (IllegalArgumentException e) {
			//do nothing
		}
	}
	
	@Test
	public void testPowerReturnsOneWhenExponentIsZero() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(1, functions.power(10, 0));
	}
	
	@Test
	public void testPowerReturnsExpectedValues() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(1, functions.power(0, 0));
		assertEquals(100, functions.power(10, 2));
		assertEquals(125, functions.power(5, 3));
		assertEquals(81, functions.power(3, 4));
	}
	
	@Test
	public void testPowerReturnsExpectedValuesWithNegativeBase() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(100, functions.power(-10, 2));
		assertEquals(-125, functions.power(-5, 3));
		assertEquals(81, functions.power(-3, 4));
	}
	
	@Test
	public void testPowerDoubleReturnsExceptionWhenExponentIsNegative() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		try {
			functions.power(5.1, -1);
			fail("Power double should throw exception illegal argument");
		} catch (IllegalArgumentException e) {
			//do nothing
		}
	}
	
	@Test
	public void testPowerDoubleReturnsOneWhenExponentIsZero() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(1.0, functions.power(10.0, 0),0);
	}
	
	@Test
	public void testPowerDoubleReturnsExpectedValues() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(30.25, functions.power(5.5, 2),0);
		assertEquals(250.047, functions.power(6.3, 3),.05);
		assertEquals(81.0, functions.power(3.0, 4),0);
	}
	
	@Test
	public void testPowerDoubleReturnsExpectedValuesWithNegativeBase() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(30.25, functions.power(-5.5, 2),0);
		assertEquals(-250.047, functions.power(-6.3, 3),.05);
		assertEquals(81.0, functions.power(-3.0, 4),0);
	}
	
	@Test
	public void testGCDIsOppositeValueIfOneIsZero() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(5, functions.gcd(5, 0));
		assertEquals(5, functions.gcd(0, 5));
	}
	
	@Test
	public void testGCDThrowsExceptionWhenBothAreZero() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		try {
			functions.gcd(0, 0);
			fail("GCD should throw exception illegal argument");
		} catch (IllegalArgumentException e) {
			//do nothing
		}
	}
	
	@Test
	public void testGCDIsWhatIsExpected() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertEquals(3, functions.gcd(15, 3));
		assertEquals(2, functions.gcd(2, 100));
		assertEquals(5, functions.gcd(-5, 20));
		assertEquals(5, functions.gcd(60, 5));
		assertEquals(1, functions.gcd(7, 2));
		assertEquals(2, functions.gcd(50, 34));
	}

	@Test
	public void testIsPalidromeReturnsTrueWhenPalidrome() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertTrue(functions.isPalindrome("racecar"));
		assertTrue(functions.isPalindrome("txt"));
		assertTrue(functions.isPalindrome("anna"));
	}
	
	@Test
	public void testIsPalidromeReturnsFalseWhenNotAPalidrome() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertFalse(functions.isPalindrome("palindrome"));
		assertFalse(functions.isPalindrome("abdeba"));
		assertFalse(functions.isPalindrome("text"));
	}
	
	@Test
	public void testIsPalidromeReturnsExpectedWithSpecialChars() {
		RecursiveFunctions functions = new RecursiveFunctions();
		
		assertTrue(functions.isPalindrome("racecar *"));
		assertTrue(functions.isPalindrome("    txt-"));
		assertTrue(functions.isPalindrome("ANNA"));
		assertTrue(functions.isPalindrome("�A man, a plan, a canal: Panama�"));
	}
}
