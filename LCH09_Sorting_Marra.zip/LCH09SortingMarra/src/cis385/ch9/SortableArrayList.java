package cis385.ch9;

import jss2.exceptions.*;
import java.util.*;

/**
 * SortableArrayList represents a sortable array implementation of a list. Since
 * it must be sortable, it can only store elements that are Comparable. The
 * front of the list is kept at array index 0.
 * @author Lewis and Chase
 * @modified by Eric Marra
 * @version 4.2 11/6/19
 */
public class SortableArrayList<T extends Comparable<? super T>>
		implements ListADT<T> {

	private final static int DEFAULT_CAPACITY = 17;
	private final static int NOT_FOUND = -1;

	protected int count;
	protected int modCount;
	protected T[] list;
	protected int medianCount;

	/**
	 * Creates an empty list using the default capacity.
	 */
	public SortableArrayList() {
		this(DEFAULT_CAPACITY);
	}

	/**
	 * Creates an empty list using the specified capacity.
	 * @param initialCapacity the integer value of the size of the array list
	 */
	@SuppressWarnings("unchecked")
	public SortableArrayList(int initialCapacity) {
		count = 0;
		list = (T[]) (new Comparable[initialCapacity]);
	}
	
	/**
	 * A getter method that will return the object at a given index
	 * in the array of objects.
	 * @param the integer of the index to return.
	 * @return the object at index i.
	 */
	public T getElement(int i) {
		return list[i];
	}

	/**
	 * Sorts the array of objects using the bubble sort algorithm.
	 */
	public void bubbleSort() {

		int rightIndex, rightScan, leftScan;
		T temp;

		// find index of last element
		rightIndex = list.length - 1;
		while (list[rightIndex] == null && rightIndex != 0)
			rightIndex--;

		// sort portion of array with elements
		for (rightScan = rightIndex; rightScan >= 0; rightScan--) {
			for (leftScan = 0; leftScan <= rightScan - 1; leftScan++) {
				if (list[leftScan].compareTo(list[leftScan + 1]) > 0) {
					/** Swap the values */
					temp = list[leftScan];
					list[leftScan] = list[leftScan + 1];
					list[leftScan + 1] = temp;
				}
			}
		}
	}
	
	/**
	 * Sorts the specified array of integers using the selection sort algorithm.
	 */
	public void selectionSort() {

		int min, limit;
		T temp;
		
		limit = list.length - 1;
		while (list[limit] == null && limit != 0)
			limit--;

		for (int index = 0; index < limit; index++) {
			min = index;
			for (int scan = index + 1; scan < limit + 1; scan++) {
				if (list[scan].compareTo(list[min]) < 0)
					min = scan;

			}
			
			/** Swap the values */
			temp = list[min];
			list[min] = list[index];
			list[index] = temp;
		}
	}
	
	/**
	 * Sorts the specified array of objects using an insertion sort algorithm.
	 */
	public void insertionSort() {
		
		int limit = list.length - 1;
		while (list[limit] == null && limit != 0)
			limit--;

		for (int index = 1; index < limit + 1; index++) {
			T key = list[index];
			int position = index;

			/** Shift larger values to the right */
			while (position > 0 && list[position - 1].compareTo(key) > 0) {
				list[position] = list[position - 1];
				position--;
			}

			list[position] = key;
		}
	}
	
	/**
	 * Sorts the specified array of objects using the merge sort algorithm.
	 */
	public void mergeSort() {
		
		int limit = list.length - 1;
		while (list[limit] == null && limit != 0)
			limit--;

		mergeSort(list, 0, limit);

	}

	/**
	 * Sorts the specified array of objects using the merge sort algorithm.
	 * @param data the array to be sorted
	 * @param min the integer representation of the minimum value
	 * @param max the integer representation of the maximum value
	 */
	@SuppressWarnings("unchecked")
	public void mergeSort(T[] data, int min, int max) {

		T[] temp;
		int index, left, right;

		/** return on list of length one */
		if (min == max)
			return;

		/** find the length and the midpoint of the list */
		int size = max - min + 1;
		int mid = (min + max) / 2;
		temp = (T[]) (new Comparable[size]);

		mergeSort(data, min, mid); // sort left half of list
		mergeSort(data, mid + 1, max); // sort right half of list

		/** copy sorted data into workspace */
		for (index = 0; index < size; index++)
			temp[index] = data[min + index];

		/** merge the two sorted lists */
		left = 0;
		right = mid - min + 1;
		for (index = 0; index < size; index++) {
			if (right <= max - min)
				if (left <= mid - min)
					if (temp[left].compareTo(temp[right]) > 0)
						data[index + min] = temp[right++];

					else
						data[index + min] = temp[left++];
				else
					data[index + min] = temp[right++];
			else
				data[index + min] = temp[left++];
		}
	}
	
	/**
	 * Sorts the array of objects using the quick sort algorithm.
	 */
	public void quickSort() {
		
		int limit = list.length - 1;
		while (list[limit] == null && limit != 0)
			limit--;

		quickSort(0, limit);
	}

	/**
	 * Sorts the specified range of an array of objects using the quick sort
	 * algorithm.
	 * @param min the array index at low end of elements being sorted
	 * @param max the array index at high end of elements being sorted
	 */
	public void quickSort(int min, int max) {

		int partitionIndex;

		if (max - min > 0) {
			/** Create partitions */
			partitionIndex = partition(min, max);

			/** Sort the left side */
			quickSort(min, partitionIndex - 1);

			/** Sort the right side */
			quickSort(partitionIndex + 1, max);
		}
	}
	
	/**
	 * Used by the quick sort algorithm to find the partition.
	 * @param min the array index at low end of elements being sorted
	 * @param max the array index at high end of elements being sorted
	 * @return the index where the partition element ends up
	 */
	private int partition(int min, int max) {

		int left, right;
		T temp, pivot;
		int mid = (min + max) / 2;

		/** avoid worst-case choice of pivot */
		medianOfThree(min, max);

		/** use middle element as partition */
		pivot = list[mid];
		left = min;
		right = max;

		/** move pivot out of the way */
		temp = list[mid];
		list[mid] = list[min];
		list[min] = temp;

		while (left < right) {
			/** search from left for element > pivot */
			while (list[left].compareTo(pivot) <= 0 && left < right)
				left++;

			/** search from right for element < pivot */
			while (list[right].compareTo(pivot) > 0)
				right--;

			/** swap the elements */
			if (left < right) {
				temp = list[left];
				list[left] = list[right];
				list[right] = temp;
			}
		}

		/** put pivot element back in place */
		temp = list[min];
		list[min] = list[right];
		list[right] = temp;

		return right;
	}
	
	/**
	 * Sorts an array of objects using shell sort.
	 */
	public void shellSort() {

		int inner, outer;
		T temp;

		// gap sequence from Pratt 1971
		// ((3^k) - 1) / 2
		// 1, 4, 13, 40, 121, 364, 1093
		int h = 1;
		while (h <= count / 3)
			h = h * 3 + 1;

		while (h > 0) {
			for (outer = h; outer < count; outer++) {
				temp = list[outer];
				inner = outer;
				while (inner > h - 1 && list[inner - h].compareTo(temp) >= 0) {
					list[inner] = list[inner - h];
					inner -= h;
				}
				list[inner] = temp;
			}
			h = (h - 1) / 3;
		}
	}
	
	/**
	 * Compare the left right and middle indices of the array and swap accordingly.
	 * @param left
	 * @param right
	 */
	public void medianOfThree(int left, int right) {
		
		int center = (left + right) / 2;
		T temp = null;
		
		// order left & center
		if (list[left].compareTo(list[center]) > 0) {
			//swap(left, center);
			temp = list[left];
			list[left] = list[center];
			list[center] = temp;
		}

		// order left & right
		if (list[left].compareTo(list[right]) > 0) {
			temp = list[left];
			list[left] = list[right];
			list[right] = temp;
		}

		// order center & right
		if (list[center].compareTo(list[right]) > 0) {
			temp = list[center];
			list[center] = list[right];
			list[right] = temp;
		}
	}
	
	/**
	 * Creates a new array to store the contents of this list with twice the
	 * capacity of the old one. Called by descendant classes that add elements
	 * to the list.
	 */
	protected void expandCapacity() {

		list = Arrays.copyOf(list, list.length * 2);
	}

	/**
	 * Adds the specified element to the front of this list.
	 * @param element the element to be added to the front of the list
	 */
	public void addToFront(T element) {

		if (size() == list.length)
			expandCapacity();

		/** shift elements to make room */
		for (int scan = count; scan > 0; scan--)
			list[scan] = list[scan - 1];

		list[0] = element;
		count++;
		modCount++;
	}

	/**
	 * Adds the specified element to the rear of this list.
	 * @param element the element to be added to the list
	 */
	public void addToRear(T element) {

		if (size() == list.length)
			expandCapacity();

		list[count++] = element;
		modCount++;
	}

	/**
	 * Adds the specified element after the specified target element. Throws an
	 * ElementNotFoundException if the target is not found.
	 * @param element the element to be added after the target element
	 * @param target the target that the element is to be added after
	 */
	public void addAfter(T element, T target) {

		if (size() == list.length)
			expandCapacity();

		int scan = 0;
		while (scan < count && !target.equals(list[scan]))
			scan++;

		if (scan == count)
			throw new ElementNotFoundException("list");

		scan++;
		for (int scan2 = count; scan2 > scan; scan2--)
			list[scan2] = list[scan2 - 1];

		list[scan] = element;
		count++;
		modCount++;
	}
	

	/**
	 * Removes and returns the last element in this list.
	 * @return the last element in the list
	 * @throws EmptyCollectionException if the element is not in the list
	 */
	public T removeLast() throws EmptyCollectionException {

		if (isEmpty())
			throw new EmptyCollectionException("ArrayList");

		T result;
		count--;
		modCount++;
		result = list[count];
		list[count] = null;

		return result;
	}

	/**
	 * Removes and returns the first element in this list.
	 * @return the first element in the list
	 * @throws EmptyCollectionException if the element is not in the list
	 */
	public T removeFirst() throws EmptyCollectionException {

		if (isEmpty())
			throw new EmptyCollectionException("ArrayList");

		T result = list[0];
		count--;
		modCount++;
		/** shift the elements */
		for (int scan = 0; scan < count; scan++)
			list[scan] = list[scan + 1];

		list[count] = null;

		return result;
	}

	/**
	 * Removes and returns the specified element.
	 * @param element the element to be removed and returned from the list
	 * @return the removed elememt
	 * @throws ElementNotFoundException if the element is not in the list
	 */
	public T remove(T element) {

		T result;
		int index = find(element);

		if (index == NOT_FOUND)
			throw new ElementNotFoundException("ArrayList");

		result = list[index];
		count--;
		modCount++;

		for (int scan = index; scan < count; scan++)
			list[scan] = list[scan + 1];

		list[count] = null;

		return result;
	}

	/**
	 * Returns a reference to the element at the front of this list. The element
	 * is not removed from the list. Throws an EmptyCollectionException if the
	 * list is empty.
	 * @return a reference to the first element in the list
	 * @throws EmptyCollectionException if the list is empty
	 */
	public T first() throws EmptyCollectionException {

		if (isEmpty())
			throw new EmptyCollectionException("ArrayList");

		return list[0];
	}

	/**
	 * Returns a reference to the element at the rear of this list. The element
	 * is not removed from the list. Throws an EmptyCollectionException if the
	 * list is empty.
	 * @return a reference to the last element of this list
	 * @throws EmptyCollectionException if the list is empty
	 */
	public T last() throws EmptyCollectionException {

		if (isEmpty())
			throw new EmptyCollectionException("ArrayList");

		return list[count - 1];
	}

	/**
	 * Returns true if this list contains the specified element.
	 * @param target the target element
	 * @return true if the target is in the list, false otherwise
	 */
	public boolean contains(T target) {

		return (find(target) != NOT_FOUND);
	}

	/**
	 * Returns the array index of the specified element, or the constant
	 * NOT_FOUND if it is not found.
	 * @param target the target element
	 * @return the index of the target element, or the NOT_FOUND constant
	 */
	private int find(T target) {

		int scan = 0;
		int result = NOT_FOUND;

		if (!isEmpty())
			while (result == NOT_FOUND && scan < count)
				if (target.equals(list[scan]))
					result = scan;
				else
					scan++;

		return result;
	}

	/**
	 * Returns true if this list is empty and false otherwise.
	 * @return true if the list is empty, false otherwise
	 */
	public boolean isEmpty() {

		return (count == 0);
	}

	/**
	 * Returns the number of elements currently in this list.
	 * @return the number of elements in the list
	 */
	public int size() {

		return count;
	}

	/**
	 * Returns a string representation of this list.
	 * @return the string representation of the list
	 */
	public String toString() {

		String result = "";

		Iterator<T> iterator = iterator();
		while (iterator.hasNext()) {
			result += iterator.next() + "\n";
		}

		return result;
	}

	@Override
	public Iterator<T> iterator() {

		return new ArrayListIterator();
	}

	/**
	 * ArrayListIterator iterator over the elements of an ArrayList.
	 */
	private class ArrayListIterator implements Iterator<T> {

		int iteratorModCount;
		int current;

		/**
		 * Sets up this iterator using the specified modCount.
		 * @param modCount the current modification count for the ArrayList
		 */
		public ArrayListIterator() {
			iteratorModCount = modCount;
			current = 0;
		}

		/**
		 * Returns true if this iterator has at least one more element to
		 * deliver in the iteration.
		 * @return true if this iterator has at least one more element to
		 *         deliver in the iteration
		 * @throws ConcurrentModificationException if the collection has changed
		 *             while the iterator is in use
		 */
		public boolean hasNext() throws ConcurrentModificationException {

			if (iteratorModCount != modCount)
				throw new ConcurrentModificationException();

			return (current < count);
		}

		/**
		 * Returns the next element in the iteration. If there are no more
		 * elements in this iteration, a NoSuchElementException is thrown.
		 * @return the next element in the iteration
		 * @throws NoSuchElementException if an element not found exception
		 *             occurs
		 * @throws ConcurrentModificationException if the collection has changed
		 */
		public T next() throws ConcurrentModificationException {

			if (!hasNext())
				throw new NoSuchElementException();

			current++;

			return list[current - 1];
		}

		/**
		 * The remove operation is not supported in this collection.
		 * @throws UnsupportedOperationException if the remove method is called
		 */
		public void remove() throws UnsupportedOperationException {

			throw new UnsupportedOperationException();
		}
	}
}
