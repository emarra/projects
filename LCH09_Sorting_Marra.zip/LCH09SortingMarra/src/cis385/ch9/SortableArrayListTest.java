/**
 * Testing program for different sorting methods.
 * @author Eric Marra
 */

package cis385.ch9;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import reference.lewis.Employee;

public class SortableArrayListTest {

	SortableArrayList<Employee> emptyList = new SortableArrayList<Employee>(10);
	SortableArrayList<Employee> oneElement = new SortableArrayList<Employee>(10);
	SortableArrayList<Employee> multiElementSorted = new SortableArrayList<Employee>(10);
	SortableArrayList<Employee> multiElementUnsorted = new SortableArrayList<Employee>(10);
	SortableArrayList<Employee> fullList = new SortableArrayList<Employee>(10);

	/**
	 * Determine if array is sorted
	 * @param array an array of Employees
	 * @return true if sorted; otherwise false
	 */
	private boolean isSorted(SortableArrayList<Employee> array) {
		
		for (int i = 0; i < array.count - 1; i ++) {
			if(array.getElement(i + 1) == null) {
				break;
			}
			Employee s1 = array.getElement(i);
			Employee s2 = array.getElement(i + 1);
			if(s1.compareTo(s2) > 0) {
				return false;
			}
		}
		
		return true;
	}
	
	@Before
	public void setUp() throws Exception {
		Employee e1 = new Employee("Alice", "Robinson", "610-55-7384");
		Employee e2 = new Employee("Don", "Robinson", "215-55-3827");
		Employee e3 = new Employee("Jason", "Mudge", "488-55-6775");
		Employee e4 = new Employee("Dilip", "Dasgupta", "663-55-3984");
		Employee e5 = new Employee("Phil", "Genet", "464-55-3489");
		Employee e6 = new Employee("W", "Sanchez", "322-55-2284");
		Employee e7 = new Employee("Tunc", "Blumenthal", "243-55-2837");
		Employee e8 = new Employee("Della", "Lu", "356-55-6457");
		Employee e9 = new Employee("Marta", "Korolev", "783-55-2485");
		Employee e10 = new Employee("Steven", "Fraley", "215-55-2426");
		
		oneElement.addToFront(e1);
		
		multiElementSorted.addToFront(e2);
		multiElementSorted.addToFront(e1);
		multiElementSorted.addToFront(e3);
		
		multiElementUnsorted.addToFront(e1);
		multiElementUnsorted.addToFront(e3);
		multiElementUnsorted.addToFront(e2);
		
		fullList.addToFront(e1);
		fullList.addToFront(e2);
		fullList.addToFront(e3);
		fullList.addToFront(e4);
		fullList.addToFront(e5);
		fullList.addToFront(e6);
		fullList.addToFront(e7);
		fullList.addToFront(e8);
		fullList.addToFront(e9);
		fullList.addToFront(e10);
		
	}

	@Test
	public void testBubbleSort() {
		emptyList.bubbleSort();
		assertTrue(isSorted(emptyList));
	
		multiElementSorted.bubbleSort();
		assertTrue(isSorted(multiElementSorted));

		multiElementUnsorted.bubbleSort();
		assertTrue(isSorted(multiElementUnsorted));
		
		fullList.bubbleSort();
		assertTrue(isSorted(fullList));
	}
	
	@Test
	public void testSelectionSort() {
		emptyList.selectionSort();
		assertTrue(isSorted(emptyList));
	
		multiElementSorted.selectionSort();
		assertTrue(isSorted(multiElementSorted));

		multiElementUnsorted.selectionSort();
		assertTrue(isSorted(multiElementUnsorted));
		
		fullList.selectionSort();
		assertTrue(isSorted(fullList));
	}
	
	@Test
	public void testInsertionSort() {
		emptyList.insertionSort();
		assertTrue(isSorted(emptyList));
	
		multiElementSorted.insertionSort();
		assertTrue(isSorted(multiElementSorted));

		multiElementUnsorted.insertionSort();
		assertTrue(isSorted(multiElementUnsorted));
		
		fullList.insertionSort();
		assertTrue(isSorted(fullList));
	}
	
	@Test
	public void testMergeSort() {
		emptyList.mergeSort();
		assertTrue(isSorted(emptyList));
	
		multiElementSorted.mergeSort();
		assertTrue(isSorted(multiElementSorted));

		multiElementUnsorted.mergeSort();
		assertTrue(isSorted(multiElementUnsorted));
		
		fullList.mergeSort();
		assertTrue(isSorted(fullList));
	}
	
	@Test
	public void testQuickSort() {
		emptyList.quickSort();
		assertTrue(isSorted(emptyList));
	
		multiElementSorted.quickSort();
		assertTrue(isSorted(multiElementSorted));

		multiElementUnsorted.quickSort();
		assertTrue(isSorted(multiElementUnsorted));
		
		fullList.quickSort();
		assertTrue(isSorted(fullList));
	}

	@Test
	public void testShellSort() {
		emptyList.shellSort();
		assertTrue(isSorted(emptyList));
	
		multiElementSorted.shellSort();
		assertTrue(isSorted(multiElementSorted));

		multiElementUnsorted.shellSort();
		assertTrue(isSorted(multiElementUnsorted));
		
		fullList.shellSort();
		assertTrue(isSorted(fullList));
	}
	
	@Test
	public void testMeidanOfThree() {
		Employee e1 = multiElementSorted.getElement(0); //M. Jason
		Employee e2 = multiElementSorted.getElement(1); //R. Alice
		Employee e3 = multiElementSorted.getElement(2); //R. Don
		
		multiElementSorted.medianOfThree(0, 2);
		
		assertEquals(multiElementSorted.getElement(0), e1); //M. Jason
		assertEquals(multiElementSorted.getElement(1), e2); //R. Alice
		assertEquals(multiElementSorted.getElement(2), e3); //R. Don
		
		e1 = multiElementUnsorted.getElement(0); //R. Don
		e2 = multiElementUnsorted.getElement(1); //M. Jason
		e3 = multiElementUnsorted.getElement(2); //R. Alice
		
		multiElementUnsorted.medianOfThree(0, 2);
		
		assertEquals(multiElementSorted.getElement(0), e2); //M. Jason
		assertEquals(multiElementSorted.getElement(1), e3); //R. Alice
		assertEquals(multiElementSorted.getElement(2), e1);	//R. Don
		
		e1 = fullList.getElement(0); //F. Steven
		e2 = fullList.getElement(4); //S. W
		e3 = fullList.getElement(9); //R. Alice
		
		fullList.medianOfThree(0, 9);
		
		assertEquals(fullList.getElement(0), e1); //F. Steven
		assertEquals(fullList.getElement(4), e3); //R. Alice
		assertEquals(fullList.getElement(9), e2); //S. W
	}	
}
