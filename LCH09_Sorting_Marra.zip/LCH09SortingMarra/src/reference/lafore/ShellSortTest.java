/**
 * TestShellSort.java Robert Lafore
 */
package reference.lafore;

public class ShellSortTest {

	/**
	 * Tester class for shell sort
	 * @author Lafore, Robert
	 */
	public static void main(String[] args) {

		int maxSize = 23;
		ShellSort arr;
		arr = new ShellSort(maxSize);

		for (int j = 0; j < maxSize; j++) {
			long n = (int) (java.lang.Math.random() * 999);
			arr.insert(n);
		}
		arr.display();
		arr.shellSort();
		arr.display();
	}
}
