/**
 * A class to create a Employee object using a firstname, lastname and ID number
 * @author Eric Marra
 */

package reference.lewis;

public class Employee implements Comparable<Employee> {

	private String firstName, lastName, employeeID;

	/**
	 * Sets up this contact with the specified information.
	 * 
	 * @param first a string representation of a first name
	 * @param last a string representation of a last name
	 * @param sSN a string representation of a employeeID number
	 */
	public Employee(String first, String last, String sSN) {

		firstName = first;
		lastName = last;
		employeeID = sSN;
	}

	/**
	 * Returns a description of this contact as a string.
	 * 
	 * @return a string representation of this contact
	 */
	public String toString() {

		return lastName + ", " + firstName + "\t" + employeeID;
	}

	/**
	 * Uses both last and first names to determine lexical ordering.
	 * 
	 * @param other the contact to be compared to this contact
	 * @return the integer result of the comparison
	 */
	public int compareTo(Employee other) {

		int result;

		if (lastName.equals(other.lastName))
			result = firstName.compareTo(other.firstName);
		else
			result = lastName.compareTo(other.lastName);

		return result;

	}
}
