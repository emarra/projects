package reference.lewis;

/**
 * Sorting defines sort methods that operate on arrays of objects.
 * @author Dr. Chase
 * @author Dr. Lewis
 * @author Dr. Rohrbaugh
 * @version 1.1, 10/29/2015
 */

public class SortingMethods {

	/**
	 * Sorts the specified array of objects using a bubble sort algorithm.
	 * @param data the array to be sorted
	 */
	public static <T extends Comparable<? super T>> void bubbleSort(T[] data) {

		int rightIndex, rightScan, leftScan;
		T temp;

		// find index of last element
		rightIndex = data.length - 1;
		while (data[rightIndex] == null && rightIndex != 0)
			rightIndex--;

		// sort portion of array with elements
		for (rightScan = rightIndex; rightScan >= 0; rightScan--) {
			for (leftScan = 0; leftScan <= rightScan - 1; leftScan++) {
				if (data[leftScan].compareTo(data[leftScan + 1]) > 0) {
					/** Swap the values */
					temp = data[leftScan];
					data[leftScan] = data[leftScan + 1];
					data[leftScan + 1] = temp;
				}
			}
		}
	}

	/**
	 * Sorts the specified array of integers using the selection sort algorithm.
	 * @param data the array to be sorted
	 */
	public static <T extends Comparable<? super T>> void selectionSort(
			T[] data) {

		int min, limit;
		T temp;
		
		limit = data.length - 1;
		while (data[limit] == null && limit != 0)
			limit--;

		for (int index = 0; index < limit; index++) {
			min = index;
			for (int scan = index + 1; scan < limit + 1; scan++) {
				if (data[scan].compareTo(data[min]) < 0)
					min = scan;

			}
			
			/** Swap the values */
			temp = data[min];
			data[min] = data[index];
			data[index] = temp;
		}
	}

	/**
	 * Sorts the specified array of objects using an insertion sort algorithm.
	 * @param data the array to be sorted
	 */
	public static <T extends Comparable<? super T>> void insertionSort(
			T[] data) {
		
		int limit = data.length - 1;
		while (data[limit] == null && limit != 0)
			limit--;

		for (int index = 1; index < limit + 1; index++) {
			T key = data[index];
			int position = index;

			/** Shift larger values to the right */
			while (position > 0 && data[position - 1].compareTo(key) > 0) {
				data[position] = data[position - 1];
				position--;
			}

			data[position] = key;
		}
	}

	/**
	 * Sorts the specified array of objects using the merge sort algorithm.
	 * @param data the array to be sorted
	 */
	public static <T extends Comparable<? super T>> void mergeSort(T[] data) {
		
		int limit = data.length - 1;
		while (data[limit] == null && limit != 0)
			limit--;

		mergeSort(data, 0, limit);

	}

	/**
	 * Sorts the specified array of objects using the merge sort algorithm.
	 * @param data the array to be sorted
	 * @param min the integer representation of the minimum value
	 * @param max the integer representation of the maximum value
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Comparable<? super T>> void mergeSort(T[] data,
			int min, int max) {

		T[] temp;
		int index, left, right;

		/** return on list of length one */
		if (min == max)
			return;

		/** find the length and the midpoint of the list */
		int size = max - min + 1;
		int mid = (min + max) / 2;
		temp = (T[]) (new Comparable[size]);

		mergeSort(data, min, mid); // sort left half of list
		mergeSort(data, mid + 1, max); // sort right half of list

		/** copy sorted data into workspace */
		for (index = 0; index < size; index++)
			temp[index] = data[min + index];

		/** merge the two sorted lists */
		left = 0;
		right = mid - min + 1;
		for (index = 0; index < size; index++) {
			if (right <= max - min)
				if (left <= mid - min)
					if (temp[left].compareTo(temp[right]) > 0)
						data[index + min] = temp[right++];

					else
						data[index + min] = temp[left++];
				else
					data[index + min] = temp[right++];
			else
				data[index + min] = temp[left++];
		}
	}

	/**
	 * Sorts the array of objects using the quick sort algorithm.
	 * @param data the array to be sorted
	 */
	public static <T extends Comparable<? super T>> void quickSort(T[] data) {
		
		int limit = data.length - 1;
		while (data[limit] == null && limit != 0)
			limit--;

		quickSort(data, 0, limit);
	}

	/**
	 * Sorts the specified range of an array of objects using the quick sort
	 * algorithm.
	 * @param data the array to be sorted
	 * @param min the array index at low end of elements being sorted
	 * @param max the array index at high end of elements being sorted
	 */
	public static <T extends Comparable<? super T>> void quickSort(T[] data,
			int min, int max) {

		int partitionIndex;

		if (max - min > 0) {
			/** Create partitions */
			partitionIndex = partition(data, min, max);

			/** Sort the left side */
			quickSort(data, min, partitionIndex - 1);

			/** Sort the right side */
			quickSort(data, partitionIndex + 1, max);
		}
	}

	/**
	 * Used by the quick sort algorithm to find the partition.
	 * @param data the array to be sorted
	 * @param min the array index at low end of elements being sorted
	 * @param max the array index at high end of elements being sorted
	 * @return the index where the partition element ends up
	 */
	private static <T extends Comparable<? super T>> int partition(T[] data,
			int min, int max) {

		int left, right;
		T temp, pivot;
		int mid = (min + max) / 2;

		/** avoid worst-case choice of pivot */
		medianOfThree(data, min, mid, max);

		/** use middle element as partition */
		pivot = data[mid];
		left = min;
		right = max;

		/** move pivot out of the way */
		temp = data[mid];
		data[mid] = data[min];
		data[min] = temp;

		while (left < right) {
			/** search from left for element > pivot */
			while (data[left].compareTo(pivot) <= 0 && left < right)
				left++;

			/** search from right for element < pivot */
			while (data[right].compareTo(pivot) > 0)
				right--;

			/** swap the elements */
			if (left < right) {
				temp = data[left];
				data[left] = data[right];
				data[right] = temp;
			}
		}

		/** put pivot element back in place */
		temp = data[min];
		data[min] = data[right];
		data[right] = temp;

		return right;
	}

	/**
	 * 
	 * @param array
	 * @param left
	 * @param mid
	 * @param right
	 */
	private static void medianOfThree(Comparable[] array, int left, int mid,
			int right) {

		// TODO: implement medianOfThree
		// compare left and mid elements, swap if necessary
		// compare left and right elements, swap if necessary
		// compare mid and right elements, swap if necessary
	}

}
