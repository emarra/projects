package reference.lewis;

/**
 * SortRoster driver for testing an object selection sort.
 * @author Lewis & Chase (original code)
 * @author Gene Rohrbaugh
 * @version 2.1, 10/29/2015
 */

public class SortingMethodsDemo {

	/**
	 * Creates an array of Student objects, sorts them, then prints them.
	 */
	public static void main(String[] args) {

		Employee[] roster = new Employee[16];

		roster[0] = new Employee("Alice", "Robinson", "610-55-7384");
		roster[1] = new Employee("Don", "Robinson", "215-55-3827");
		roster[2] = new Employee("Jason", "Mudge", "488-55-6775");
		roster[3] = new Employee("Dilip", "Dasgupta", "663-55-3984");
		roster[4] = new Employee("Phil", "Genet", "464-55-3489");
		roster[5] = new Employee("W", "Sanchez", "322-55-2284");
		roster[6] = new Employee("Tunc", "Blumenthal", "243-55-2837");
		roster[7] = new Employee("Della", "Lu", "356-55-6457");
		roster[8] = new Employee("Marta", "Korolev", "783-55-2485");
		roster[9] = new Employee("Steven", "Fraley", "215-55-2426");
		roster[10] = new Employee("Marsha", "Grant", "409-55-7533");
		roster[11] = new Employee("Wil", "Brierson", "786-55-2775");
		roster[12] = new Employee("Rohan", "Dasgupta", "476-55-1131");
		roster[13] = new Employee("Tammy", "Robinson", "324-55-2548");
		roster[14] = new Employee("Juan", "Chanson", "994-55-9941");
		roster[15] = new Employee("Monica", "Raines", "265-55-2241");

		System.out.println("Student list before sorting:");
		for (int index = 0; index < roster.length; index++) {
			if (roster[index] != null)
				System.out.println(roster[index]);
		}

		SortingMethods.bubbleSort(roster);
		SortingMethods.selectionSort(roster);
		SortingMethods.insertionSort(roster);
		SortingMethods.mergeSort(roster);
		SortingMethods.quickSort(roster);

		System.out.println("\nContact list after sorting:");
		for (int index = 0; index < roster.length; index++) {
			if (roster[index] != null)
				System.out.println(roster[index]);
		}
	}
}
