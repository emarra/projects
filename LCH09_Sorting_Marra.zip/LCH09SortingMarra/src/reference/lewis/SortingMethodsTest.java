/**
 * A testing program to test the sorting methods using an array of objects
 * @author Eric Marra
 */
package reference.lewis;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SortingMethodsTest {
	
	Employee[] roster = new Employee[16];
	Employee[] partialRoster = new Employee[16];
	Employee[] emptyRoster = new Employee[16];
	

	/**
	 * Determine if array is sorted
	 * @param array an array of Employees
	 * @return true if sorted; otherwise false
	 */
	private boolean isSorted(Employee[] array) {
		
		for (int i = 0; i < array.length - 1; i ++) {
			if(array[i + 1] == null) {
				break;
			}
			
			if(array[i].compareTo(array[i + 1]) > 0) {
				return false;
			}
		}
		
		return true;
	}

	
	@Before
	public void setUp() throws Exception {

		roster[0] = new Employee("Alice", "Robinson", "610-55-7384");
		roster[1] = new Employee("Don", "Robinson", "215-55-3827");
		roster[2] = new Employee("Jason", "Mudge", "488-55-6775");
		roster[3] = new Employee("Dilip", "Dasgupta", "663-55-3984");
		roster[4] = new Employee("Phil", "Genet", "464-55-3489");
		roster[5] = new Employee("W", "Sanchez", "322-55-2284");
		roster[6] = new Employee("Tunc", "Blumenthal", "243-55-2837");
		roster[7] = new Employee("Della", "Lu", "356-55-6457");
		roster[8] = new Employee("Marta", "Korolev", "783-55-2485");
		roster[9] = new Employee("Steven", "Fraley", "215-55-2426");
		roster[10] = new Employee("Marsha", "Grant", "409-55-7533");
		roster[11] = new Employee("Wil", "Brierson", "786-55-2775");
		roster[12] = new Employee("Rohan", "Dasgupta", "476-55-1131");
		roster[13] = new Employee("Tammy", "Robinson", "324-55-2548");
		roster[14] = new Employee("Juan", "Chanson", "994-55-9941");
		roster[15] = new Employee("Monica", "Raines", "265-55-2241");
		
		partialRoster[0] = new Employee("Alice", "Robinson", "610-55-7384");
		partialRoster[1] = new Employee("Don", "Robinson", "215-55-3827");
		partialRoster[2] = new Employee("Jason", "Mudge", "488-55-6775");
		partialRoster[3] = new Employee("Dilip", "Dasgupta", "663-55-3984");
		partialRoster[4] = new Employee("Phil", "Genet", "464-55-3489");
		partialRoster[5] = new Employee("W", "Sanchez", "322-55-2284");
		partialRoster[6] = new Employee("Tunc", "Blumenthal", "243-55-2837");
		partialRoster[7] = new Employee("Della", "Lu", "356-55-6457");
				
	}

	@Test
	public void testBubbleSort() {
		
		SortingMethods.bubbleSort(roster);
		assertTrue(isSorted(roster));
		
		SortingMethods.bubbleSort(partialRoster);
		assertTrue(isSorted(partialRoster));
		
		SortingMethods.bubbleSort(emptyRoster);
		assertTrue(isSorted(emptyRoster));
	}

	@Test
	public void testSelectionSort() {
		
		SortingMethods.selectionSort(roster);
		assertTrue(isSorted(roster));
		
		SortingMethods.selectionSort(partialRoster);
		assertTrue(isSorted(partialRoster));
		
		SortingMethods.bubbleSort(emptyRoster);
		assertTrue(isSorted(emptyRoster));
	}

	@Test
	public void testInsertionSort() {

		SortingMethods.insertionSort(roster);
		assertTrue(isSorted(roster));
		
		SortingMethods.insertionSort(partialRoster);
		assertTrue(isSorted(partialRoster));
		
		SortingMethods.bubbleSort(emptyRoster);
		assertTrue(isSorted(emptyRoster));
	}

	@Test
	public void testMergeSortTArray() {
		
		SortingMethods.mergeSort(roster);
		assertTrue(isSorted(roster));
		
		SortingMethods.mergeSort(partialRoster);
		assertTrue(isSorted(partialRoster));
		
		SortingMethods.bubbleSort(emptyRoster);
		assertTrue(isSorted(emptyRoster));
	}

	@Test
	public void testQuickSortTArray() {
		
		SortingMethods.quickSort(roster);
		assertTrue(isSorted(roster));
		
		SortingMethods.quickSort(partialRoster);
		assertTrue(isSorted(partialRoster));
		
		SortingMethods.bubbleSort(emptyRoster);
		assertTrue(isSorted(emptyRoster));
	}

}
